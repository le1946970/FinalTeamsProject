﻿namespace FinalProject
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.movieListView = new System.Windows.Forms.ListView();
            this.showTimeListView = new System.Windows.Forms.ListView();
            this.purchaseButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // movieListView
            // 
            this.movieListView.HideSelection = false;
            this.movieListView.Location = new System.Drawing.Point(31, 29);
            this.movieListView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.movieListView.Name = "movieListView";
            this.movieListView.Size = new System.Drawing.Size(329, 400);
            this.movieListView.TabIndex = 134;
            this.movieListView.UseCompatibleStateImageBehavior = false;
            // 
            // showTimeListView
            // 
            this.showTimeListView.HideSelection = false;
            this.showTimeListView.Location = new System.Drawing.Point(366, 29);
            this.showTimeListView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.showTimeListView.Name = "showTimeListView";
            this.showTimeListView.Size = new System.Drawing.Size(271, 400);
            this.showTimeListView.TabIndex = 135;
            this.showTimeListView.UseCompatibleStateImageBehavior = false;
            // 
            // purchaseButton
            // 
            this.purchaseButton.Location = new System.Drawing.Point(492, 454);
            this.purchaseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.purchaseButton.Name = "purchaseButton";
            this.purchaseButton.Size = new System.Drawing.Size(145, 33);
            this.purchaseButton.TabIndex = 153;
            this.purchaseButton.Text = "Purchase";
            this.purchaseButton.UseVisualStyleBackColor = true;
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 510);
            this.Controls.Add(this.purchaseButton);
            this.Controls.Add(this.showTimeListView);
            this.Controls.Add(this.movieListView);
            this.Name = "ClientForm";
            this.Text = "Client";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView movieListView;
        private System.Windows.Forms.ListView showTimeListView;
        private System.Windows.Forms.Button purchaseButton;
    }
}
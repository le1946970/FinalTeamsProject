﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace FinalProject
{
    public partial class MainForm : Form
    {
        NpgsqlConnection dbConnection;

        //Constants for the database
        private const string DatabaseHost = "localhost";
        private const string DatabaseUser = "postgres";
        private const string DatabasePassword = "bmc";
        private const string DatabaseName = "finaldb";
        public MainForm()
        {
            InitializeComponent();

            //This method sets up a connection to a Postgres database and recieves information
            CreateDBConnection(DatabaseHost, DatabaseUser, DatabasePassword, DatabaseName);
        }
        private NpgsqlConnection CreateDBConnection(string serverAddress, string username, string password, string dbName)
        {
            string conectionString = "Host=" + serverAddress + "; Username=" + username + "; Password=" + password + "; Database=" + dbName + ";";

            dbConnection = new NpgsqlConnection(conectionString);

            return dbConnection;
        }
    }
}
